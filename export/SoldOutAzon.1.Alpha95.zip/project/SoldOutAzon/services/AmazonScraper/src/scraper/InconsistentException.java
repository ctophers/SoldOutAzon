package scraper;

public class InconsistentException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
