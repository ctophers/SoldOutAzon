
package com.soldoutazondb.data;



/**
 *  soldoutazonDB.System
 *  05/04/2015 09:17:27
 * 
 */
public class System {

    private Integer id;
    private Boolean flag;
    private String message;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Boolean getFlag() {
        return flag;
    }

    public void setFlag(Boolean flag) {
        this.flag = flag;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
