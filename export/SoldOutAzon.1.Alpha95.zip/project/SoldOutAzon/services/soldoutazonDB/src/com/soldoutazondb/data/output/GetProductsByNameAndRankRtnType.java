
package com.soldoutazondb.data.output;



/**
 * Generated for query "getProductsByNameAndRank" on 04/20/2012 23:22:59
 * 
 */
public class GetProductsByNameAndRankRtnType {

    private String name;
    private Integer id;
    private String asin;
    private String category;
    private Integer rank;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getAsin() {
        return asin;
    }

    public void setAsin(String asin) {
        this.asin = asin;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

}
