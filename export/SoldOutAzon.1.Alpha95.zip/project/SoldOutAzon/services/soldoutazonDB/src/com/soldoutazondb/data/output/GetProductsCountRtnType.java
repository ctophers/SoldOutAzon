
package com.soldoutazondb.data.output;



/**
 * Generated for query "getProductsCount" on 05/04/2015 09:17:33
 * 
 */
public class GetProductsCountRtnType {

    private Long searchCount;

    public Long getSearchCount() {
        return searchCount;
    }

    public void setSearchCount(Long searchCount) {
        this.searchCount = searchCount;
    }

}
