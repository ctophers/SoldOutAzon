
package com.soldoutazondb.data.output;



/**
 * Generated for query "getCategory" on 05/04/2015 09:17:33
 * 
 */
public class GetCategoryRtnType {

    private String c0;

    public String getC0() {
        return c0;
    }

    public void setC0(String c0) {
        this.c0 = c0;
    }

}
