package scraper;

public class ConfigConstants {
	
	public ConfigConstants() {
	}
	
	public static final String DELETE_CNT = "DELETE_CNT";
	public static final String DELETE_START = "DELETE_STR";
	public static final String DELETE_END = "DELETE_END";

}
