
package com.soldoutazondb.data.output;



/**
 * Generated for query "getCategory" on 04/28/2015 17:50:21
 * 
 */
public class GetCategoryRtnType {

    private String c0;

    public String getC0() {
        return c0;
    }

    public void setC0(String c0) {
        this.c0 = c0;
    }

}
