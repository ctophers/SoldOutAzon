package scraper;

public class DuplicateException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
