
package com.soldoutazondb.data.output;



/**
 * Generated for query "getProductsCount" on 04/28/2015 17:50:21
 * 
 */
public class GetProductsCountRtnType {

    private Long searchCount;

    public Long getSearchCount() {
        return searchCount;
    }

    public void setSearchCount(Long searchCount) {
        this.searchCount = searchCount;
    }

}
